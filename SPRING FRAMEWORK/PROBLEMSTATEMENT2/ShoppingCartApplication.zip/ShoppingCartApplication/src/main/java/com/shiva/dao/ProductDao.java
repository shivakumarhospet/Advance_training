package com.shiva.dao;



import java.util.List;

import com.shiva.model.Product;

public interface ProductDao {
	
	Long addProduct(Product product);
	
	List<Product> getAllProducts();
	
	Product editProduct(Product product);
	
	Product getProductById(Long id);
	
	Product deleteProduct(Long id);

}

    