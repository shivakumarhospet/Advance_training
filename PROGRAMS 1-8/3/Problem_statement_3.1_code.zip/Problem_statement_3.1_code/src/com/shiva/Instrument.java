package com.shiva;

public abstract class Instrument {
	public abstract void play();
}
